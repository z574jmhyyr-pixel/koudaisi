extends SceneTree

func _initialize() -> void:
	call_deferred("_verify")

func _verify() -> void:
	var failures: Array[String] = []
	var packed := load("res://comparison.tscn") as PackedScene
	if packed == null:
		push_error("Comparison scene did not load")
		quit(1)
		return
	var scene := packed.instantiate()
	root.add_child(scene)
	await process_frame
	var cloud := scene.get_node("Cloud") as AnimatedSprite2D
	var shadow := scene.get_node("Shadow") as AnimatedSprite2D
	var reference := cloud.sprite_frames
	var target := shadow.sprite_frames
	if reference.get_frame_count(&"walk") != 8 or reference.get_animation_speed(&"walk") != 8.0 or not reference.get_animation_loop(&"walk"):
		failures.append("Unexpected reference configuration")
	for anim in [&"walk", &"walk_blink"]:
		if target.get_frame_count(anim) != reference.get_frame_count(&"walk"):
			failures.append("Frame count mismatch")
		if target.get_animation_speed(anim) != reference.get_animation_speed(&"walk") or not target.get_animation_loop(anim):
			failures.append("Timing mismatch")
		for i in range(8):
			if target.get_frame_duration(anim, i) != reference.get_frame_duration(&"walk", i):
				failures.append("Frame duration mismatch")
			var texture := target.get_frame_texture(anim, i) as AtlasTexture
			if texture == null or texture.region != Rect2(i * 300, 0, 300, 300):
				failures.append("Atlas region mismatch")
			var image := texture.get_image()
			if image.get_size() != Vector2i(300, 300) or image.get_pixel(0, 0).a != 0.0:
				failures.append("Image canvas or alpha invalid")
			var near_y := 105 if anim == &"walk" else 110
			var far_y := 90 if anim == &"walk" else 95
			var eye_h := 10 if anim == &"walk" else 5
			if image.get_region(Rect2i(185, near_y, 20, eye_h)).get_data() != image.get_region(Rect2i(230, far_y, 20, eye_h)).get_data():
				failures.append("Eye pixels differ after Godot import")
	var changed: Array[int] = []
	cloud.frame_changed.connect(func() -> void: changed.append(cloud.frame))
	var animations_seen: Array[String] = []
	var samples := 0
	var start := Time.get_ticks_msec()
	while Time.get_ticks_msec() - start < 6600:
		await create_timer(0.03).timeout
		samples += 1
		if cloud.frame != shadow.frame or absf(cloud.frame_progress - shadow.frame_progress) > 0.005:
			failures.append("Reference and shadow phases diverged")
		if cloud.position != Vector2(240, 410) or shadow.position != Vector2(680, 410):
			failures.append("Character position changed")
		if cloud.offset != Vector2(0, -100) or shadow.offset != Vector2(0, -100):
			failures.append("Character anchor changed")
		var name := String(shadow.animation)
		if not animations_seen.has(name):
			animations_seen.append(name)
	if changed.size() < 48:
		failures.append("Playback did not advance at the configured rate")
	if absf(changed.size() - (Time.get_ticks_msec() - start) / 1000.0 * 8.0) > 2.0:
		failures.append("Observed frame rate differs from reference")
	for i in range(1, changed.size()):
		if changed[i] != (changed[i - 1] + 1) % 8:
			failures.append("Out of order reference frame")
	if not animations_seen.has("walk") or not animations_seen.has("walk_blink"):
		failures.append("Blink and normal state not both exercised")
	var result := {
		"godot_version": Engine.get_version_info().string,
		"scope": "isolated preview project, not the user's actual game project",
		"test_seconds": (Time.get_ticks_msec() - start) / 1000.0,
		"frame_count": 8, "fps": 8.0, "loop": true,
		"synchronized_samples": samples,
		"cloud_frame_transitions": changed.size(),
		"reference_frame_trace": changed,
		"shadow_animation_states": animations_seen,
		"failures": failures, "passed": failures.is_empty()
	}
	var file := FileAccess.open("res://runtime_test_results.json", FileAccess.WRITE)
	file.store_string(JSON.stringify(result, "  "))
	file.close()
	print(JSON.stringify(result))
	quit(0 if failures.is_empty() else 1)
