extends Node2D

@onready var cloud: AnimatedSprite2D = $Cloud
@onready var shadow: AnimatedSprite2D = $Shadow
var elapsed := 0.0
var paused := false

func _ready() -> void:
	Engine.max_fps = 60
	cloud.play(&"walk")
	shadow.play(&"walk")

func _process(delta: float) -> void:
	if paused:
		return
	elapsed += delta
	var t := fmod(elapsed, 8.0)
	var blinking := (t >= 65.0 / 24.0 and t < 68.0 / 24.0) or (t >= 149.0 / 24.0 and t < 152.0 / 24.0)
	var desired: StringName = &"walk_blink" if blinking else &"walk"
	if shadow.animation != desired:
		shadow.play(desired)
	# Blink only changes the eye pixels. Use the reference's phase and progress
	# so switching eye states cannot restart or accelerate the gait.
	shadow.set_frame_and_progress(cloud.frame, cloud.frame_progress)

func _unhandled_key_input(event: InputEvent) -> void:
	if event is not InputEventKey or not event.pressed or event.echo:
		return
	if event.keycode == KEY_SPACE:
		paused = not paused
		if paused:
			cloud.pause()
			shadow.pause()
		else:
			cloud.play(&"walk")
			shadow.play(shadow.animation)
	if event.keycode == KEY_R:
		paused = false
		elapsed = 0.0
		cloud.play(&"walk")
		shadow.play(&"walk")
		cloud.set_frame_and_progress(0, 0.0)
		shadow.set_frame_and_progress(0, 0.0)
