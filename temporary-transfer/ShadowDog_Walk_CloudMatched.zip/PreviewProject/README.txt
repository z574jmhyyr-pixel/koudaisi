影子狗行走修复包

ShadowDog_Walk/ 是可导入的素材：8 张正常行走帧、8 张闭眼变体、透明精灵图、SpriteFrames 和检查报告。
PreviewProject/ 是独立预览工程，附云朵狗原样副本用于动作对照，不是你的正式游戏工程。

导入自己的 Godot 工程：
只复制 ShadowDog_Walk/ 到 res:// 下任意文件夹。
保持文件夹内的相对位置，把 shadow_dog_walk.tres 指定给既有 AnimatedSprite2D 的 Sprite Frames。
选择 walk，8 FPS，Loop=true，Texture Filter=Nearest。无需修改现有移动或碰撞代码。
如果现有场景的节点类型还不是 AnimatedSprite2D，请先检查实际项目，不能直接替换节点类型。
本包没有自动操作你的正式场景。

本地运行对比：
在 Godot 项目管理器中导入 PreviewProject/project.godot，按 F6 或 F5 运行。
左侧为云朵狗参考，右侧为影子狗修复；两者使用同一相位。
Space 暂停/继续，R 从第 1 帧重新开始。
preview_project 中的脚本只服务于独立对照，不应覆盖正式项目脚本。
自动验证：godot --headless --path PreviewProject --script verify_runtime.gd

视频：shadow_dog_cloudmatched.mp4（影子狗单独预览）、cloud_shadow_comparison.mp4（左右同相位对照）。
同名 GIF 用于快速浏览。视频背景和对照标签仅属于预览，PNG 素材保持真正透明。

注意：当前仅获得此前交付素材和公开中转仓库，尚未收到实际游戏工程。
本包附 Godot 4.6.3 独立运行实测结果，不能据此声称已通过正式游戏场景验收。
