影子狗行走素材：耳朵轻摆 + 原有尾巴摆动、眨眼

在最后一版带尾巴摆动的影子狗素材基础上，增加了耳尖和耳朵下缘的轻微摆动。
耳根保持固定，运动幅度约一个原始像素颗粒；不移动整个头部。
耳朵区域之外的像素与上一版对应帧完全一致。
四肢步态、身体、五官、眨眼、项圈、尾巴摆动均保留上一版。
原始版本及其视频未被修改或覆盖。

文件用途
frames/：8 张正常行走 PNG，300×300，RGBA 真透明。
blink_frames/：同样 8 个步态相位的闭眼 PNG，耳朵与尾巴同步。
shadow_dog_walk_spritesheet.png：2400×300，横向 8 帧。
shadow_dog_blink_spritesheet.png：2400×300，横向 8 帧闭眼变体。
shadow_dog_walk_preview.png：1200×600，4列×2行透明帧预览。
shadow_dog_walk.tres：Godot SpriteFrames，walk / walk_blink，8 帧、8 FPS、循环。
preview/shadow_dog_walk_ears_tail.mp4：1200×1200，8 秒单角色预览。
preview/shadow_dog_walk_ears_tail.gif：480×480，同内容循环动图。
quality_report.json：逐帧像素检查和原始素材 SHA-256。
runtime_test_results.json：Godot 实际资源加载、AnimatedSprite2D 循环播放结果。

像素与循环
保留原有 60×60 像素网格，最近邻放大 5 倍输出 300×300。
PNG 的 Alpha 只有 0/255，没有背景、模糊、抗锯齿或平滑渐变。
全部帧使用相同尺寸与定位，脚底最后一个不透明像素为 y=249。
行走及耳朵摆动每秒一轮，第 8 帧接第 1 帧循环；不重复添加末帧。
预览视频容器为 24 FPS，每个步态帧持续 3 帧，动作实际为 8 FPS。
视频包含原有偶发眨眼时机，浅色预览背景不属于 PNG 素材。

Godot 导入
1. 将整个 ShadowDog_Walk 文件夹复制到项目 res:// 下，保持内部文件相对位置。
2. 在 AnimatedSprite2D 的 Sprite Frames 中加载 shadow_dog_walk.tres。
3. 选择 walk 并播放；资源设置为 8 FPS、循环开启。
4. 将 AnimatedSprite2D 的 Texture Filter 设为 Nearest，或沿用项目的最近邻设置。
5. walk_blink 是完整闭眼变体，可沿用已有眨眼逻辑，并保留当前 frame / frame_progress。
   默认 walk 不会自动切到 walk_blink；此包不更改项目脚本。
6. 若项目原来已经使用同名资源，只需替换这个文件夹中的图片。
   SpriteFrames 文件与上一版字节完全一致，无需改变动画名称或节奏。

验证范围
Godot 4.7.2-stable (official) 独立测试项目导入及 AnimatedSprite2D 循环测试通过。
walk 帧序列：[1, 2, 3, 4, 5, 6, 7, 0, 1, 2]。
walk_blink 帧序列：[1, 2, 3, 4, 5, 6, 7, 0, 1, 2]。
耳根固定；耳朵之外像素、腿部、尾巴、眼睛均与上一版逐帧相同。
两只眼睛的像素尺寸和颜色在 Godot 导入后仍完全一致。
所有帧轮廓通过四邻域及八邻域连通检查，耳朵未与头部分离。
没有修改现有游戏场景、移动逻辑、碰撞体或其他游戏脚本。
本包仅包含影子狗素材，不含其他角色或测试项目。
